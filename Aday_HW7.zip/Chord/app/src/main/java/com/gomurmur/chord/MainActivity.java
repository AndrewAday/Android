package com.gomurmur.chord;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.client.*;
import org.json.*;
import android.app.Activity;
import android.opengl.Visibility;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.AppEventsLogger;

public class MainActivity extends Activity {

    private EditText val;
    private Button btn;
    private ProgressBar pb;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        val = (EditText)findViewById(R.id.editText1);
//        btn = (Button)findViewById(R.id.button1);
//        pb = (ProgressBar)findViewById(R.id.progressBar1);
//        pb.setVisibility(View.GONE);
//        btn.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Logs 'install' and 'app activate' App Events.
        AppEventsLogger.activateApp(this);
    }

    @Override
    protected  void onPause() {
        super.onPause();

        AppEventsLogger.deactivateApp(this);
    }
//    public void onClick(View v) {
//        // TODO Auto-generated method stub
//        if(val.getText().toString().length()<1){
//            // out of range
//            Toast.makeText(this, "please enter something", Toast.LENGTH_LONG).show();
//        }else{
//            pb.setVisibility(View.VISIBLE);
//            new MyAsyncTask().execute(val.getText().toString());
//        }
//    }

    private class MyAsyncTask extends AsyncTask<String, Integer, Double>{
        private String server_response;
        @Override
        protected Double doInBackground(String... params) {
            // TODO Auto-generated method stub
            postData(params[0]);
            return null;
        }
        protected void onPostExecute(Double result){
            pb.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(), server_response, Toast.LENGTH_LONG).show();
        }

        protected void onProgressUpdate(Integer... progress){
            pb.setProgress(progress[0]);
        }

        public void postData(String valueIWantToSend) {
            HttpClient httpclient = new DefaultHttpClient();
            // specify the URL you want to post to
            HttpPost httppost = new HttpPost("http://chord.gomurmur.com/script.php");
            try {
                // create a list to store HTTP variables and their values
                List nameValuePairs = new ArrayList();
                // add an HTTP variable and value pair
                nameValuePairs.add(new BasicNameValuePair("myHttpData", valueIWantToSend));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                // send the variable and value, in other words post, to the URL
                // Execute HTTP Post Request
                ResponseHandler<String> responseHandler=new BasicResponseHandler();
                String responseBody = httpclient.execute(httppost, responseHandler);
                if (responseBody != null) {
                    try {
                        JSONObject response = new JSONObject(responseBody);
                        server_response = response.getString("truth");
                    } catch (JSONException e) {
                        e.printStackTrace();
                        server_response = "nothing returned";
                    }
                }

            } catch (ClientProtocolException e) {
                // process execption
                e.printStackTrace();
            } catch (IOException e) {
                // process execption
                e.printStackTrace();
            }
        }
    }
}
