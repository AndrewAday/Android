package programming.calculator;
import android.view.View;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void clear(View v) {
        final EditText value1 = (EditText) findViewById(R.id.value1);
        final EditText value2 = (EditText) findViewById(R.id.value2);
        final EditText ans = (EditText) findViewById(R.id.answer);

        value1.setText("");
        value2.setText("");
        ans.setText("");
    }

    public void operate(View v, char operator) {
        final EditText value1 = (EditText) findViewById(R.id.value1);
        final EditText value2 = (EditText) findViewById(R.id.value2);
        final EditText ans = (EditText) findViewById(R.id.answer);

        double v1 = Double.parseDouble(value1.getText().toString());
        double v2 = Double.parseDouble(value2.getText().toString());
        double answer;
        switch(operator) {
            case '+':
                answer = v1 + v2;
                ans.setText(Double.toString(answer));
                break;
            case '-':
                answer = v1 - v2;
                ans.setText(Double.toString(answer));
                break;
            case 'x':
                answer = v1 * v2;
                ans.setText(Double.toString(answer));
                break;
            case '/':
                answer = v1 / v2;
                ans.setText(Double.toString(answer));
                break;
            default:
                break;
        }
    }

    public void add(View v) {
       operate(v, '+');
    }
    public void subtract(View v) {
        operate(v,'-');
    }
    public void multiply(View v) {
        operate(v,'x');
    }
    public void divide(View v) {
        operate(v,'/');
    }

}
